import nltk
import pandas as pd


texts = "we create a dictionary for the word frequency table from the text. we create a dictionary for the word frequency table from the text. For this, we should only use the words that are not part of the stopWords array. We're using the Term Frequency method to score each sentence."


# Defining a grammar & Parser
NP = "NP: {(<V\w+>|<NN\w?>)+.*<NN\w?>}"
chunkr = nltk.RegexpParser(NP)

tokens = [nltk.word_tokenize(i) for i in texts]

tag_list = [nltk.pos_tag(w) for w in tokens]

phrases = [chunkr.parse(sublist) for sublist in tag_list]

leaves = [
    [subtree.leaves() for subtree in tree.subtrees(filter=lambda t: t.label == "NP")]
    for tree in phrases
]

