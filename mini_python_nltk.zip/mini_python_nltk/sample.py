from nltk.corpus import stopwords
from nltk.stem import PorterStemmer
from nltk.tokenize import word_tokenize, sent_tokenize

def stop_words(text) -> list:
    sentence_word=[]
    stopWords = set(stopwords.words("english"))
    words = word_tokenize(text)
    for word in words:
        if word not in stopWords:
            sentence_word.append(word)
    return sentence_word
    


text = "we create a dictionary for the word frequency table from the text. we create a dictionary for the word frequency table from the text. For this, we should only use the words that are not part of the stopWords array. We’re using the Term Frequency method to score each sentence."

sentences = sent_tokenize(text)

stop = stop_words(text)
print(stop)
#print(sentences)

